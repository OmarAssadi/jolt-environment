﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Reflection;


using ComLib;
using ComLib.Entities;
using ComLib.Database;
using ComLib.Reflection;


namespace ComLib.Entities
{
    /// <summary>
    /// Repository pattern providing CRUD( Create / Retrieve / Update / Delete ) and other methods
    /// using Linq 2 Sql.
    /// 
    /// NOTES:
    /// 1. This is slightly Hybrid version of plain dynamic sql, Linq2Sql, and stored procs
    /// 2. This requires a RowMapper and stored procedures if using the GetByFilter and GetRecent methods
    /// 3. This uses dynamic sql for the Find methods
    /// 4. Linq 2 Sql is used for Create, Update, Get, Delete methods.
    /// 5. Linq 2 Sql itself is a limited solution with the following restrictions:
    /// 
    ///     -a. Can only be used for SQL Server
    ///     -b. Only supports a 1-1 object to table mapping.
    ///     -c. The Update( T entity ) method is a workaround to the inability to attach POCO's( detached entities ) to a different DataContext.
    ///    
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class RepositoryLinq2Sql<T> : RepositoryBase<T>, IEntityRepository<T> where T : class, IEntity
    {
        private string _tableName;


        /// <summary>
        /// Initialize
        /// </summary>
        public RepositoryLinq2Sql()
        {
            Init(null, null);
        }


        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="connectionInfo"></param>
        /// <param name="helper"></param>
        public RepositoryLinq2Sql(ConnectionInfo connectionInfo)
        {
            DBHelper helper = new DBHelper(connectionInfo);
            Init(connectionInfo, helper);
        }


        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="connectionInfo"></param>
        /// <param name="helper"></param>
        public RepositoryLinq2Sql(ConnectionInfo connectionInfo, IDBHelper helper)
        {
            Init(connectionInfo, helper);
        }


        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="connectionInfo"></param>
        /// <param name="helper"></param>
        public virtual void Init(ConnectionInfo connectionInfo, IDBHelper helper)
        {
            _connectionInfo = connectionInfo;
            _db = helper;
            _db.Connection = _connectionInfo;
            _tableName = typeof(T).Name + "s";
        }


        /// <summary>
        /// Get / Set the table name.
        /// </summary>
        public string TableName
        {
            get { return _tableName; }
            set { _tableName = value; }
        }


        #region IRepository<int,T> Members
        /// <summary>
        /// Create the entity.
        /// </summary>
        /// <param name="entity"></param>
        public override T Create(T entity)
        {
            Execute((ctx, table) =>
            {
                table.InsertOnSubmit(entity);
                ctx.SubmitChanges(ConflictMode.ContinueOnConflict);
            });
            return entity;
        }


        /// <summary>
        /// Update the entity.
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public override T Update(T updatedEntity)
        {           
            Execute((ctx, table) =>
            {
                // Get the original.
                T original = table.First<T>(m => m.Id.Equals(updatedEntity.Id));

                // Now copy over all updated values from the updated to original.
                // This is the FIX / WORKAROUND for the missing feature in Linq2Sql where you can not attach
                // an entity to the Table.
                CopyValues(updatedEntity, original);

                // Now save the oringal.
                ctx.SubmitChanges(ConflictMode.ContinueOnConflict);                
            });
            return updatedEntity;
        }


        /// <summary>
        /// Save the entity
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public override T Save(T entity)
        {
            if (entity.IsPersistant())
                return Update(entity);
            return Create(entity);
        }


        /// <summary>
        /// Get the entity by the id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public T Get(int id)
        {
            T first = default(T);
            Execute((ctx, table) => first = table.First<T>(m => m.Id.Equals(id)));
            return first;
        }


        /// <summary>
        /// Get all the entities in the database as a List.
        /// </summary>
        /// <returns></returns>
        public IList<T> GetAll()
        {
            IList<T> all = null;
            Execute((ctx, table) => all = table.ToList<T>());
            return all;
        }


        /// <summary>
        /// Delete the entity from the repository
        /// </summary>
        /// <param name="id"></param>
        public override void Delete(int id)
        {
            Execute((ctx, table) =>
            {
                T entity = table.First<T>(m => m.Id.Equals(id));
                table.DeleteOnSubmit(entity);
                ctx.SubmitChanges(ConflictMode.ContinueOnConflict);
            });
        }


        /// <summary>
        /// Delete entity from the repository.
        /// </summary>
        /// <param name="entity"></param>
        public override void DeleteByEntity(T entity)
        {
            Delete(entity.Id);
        }


        /// <summary>
        /// Get all the items.
        /// </summary>
        /// <returns></returns>
        public virtual System.Collections.IList GetAllItems()
        {
            ArrayList list = new ArrayList();
            IList<T> allItems = GetAll();
            foreach (T item in allItems)
                list.Add(item);

            return list;
        }


        /// <summary>
        /// Get the first one that matches the filter.
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        public T GetFirst(string filter)
        {
            IList<T> result = FindByQuery(filter, false);
            if (result == null || result.Count == 0)
                return default(T);

            return result[0];                 
        }


        /// <summary>
        /// Get page of records using filter.
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="table"></param>
        /// <param name="pageNumber"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalRecords"></param>
        /// <returns></returns>
        public virtual PagedList<T> GetByFilter(string filter, int pageNumber, int pageSize)
        {
            string procName = TableName + "_GetByFilter";
            List<DbParameter> dbParams = new List<DbParameter>();
            dbParams.Add(DbHelper.BuildInParam("@Filter", System.Data.DbType.String, filter));
            dbParams.Add(DbHelper.BuildInParam("@PageIndex", System.Data.DbType.Int32, pageNumber));
            dbParams.Add(DbHelper.BuildInParam("@PageSize", System.Data.DbType.Int32, pageSize));
            dbParams.Add(DbHelper.BuildOutParam("@TotalRows", System.Data.DbType.Int32));

            Tuple2<IList<T>, IDictionary<string, object>> result = DbHelper.Query<T>(
                procName, System.Data.CommandType.StoredProcedure, dbParams.ToArray(), _rowMapper, new string[] { "@TotalRows" });

            // Set the total records.
            int totalRecords = (int)result.Second["@TotalRows"];
            PagedList<T> pagedList = new PagedList<T>(pageNumber, pageSize, totalRecords, result.First);
            return pagedList;
        }


        /// <summary>
        /// Get recents posts by page
        /// </summary>
        /// <param name="table"></param>
        /// <param name="pageNumber"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalRecords"></param>
        /// <returns></returns>
        public virtual PagedList<T> GetRecent(int pageNumber, int pageSize)
        {
            string procName = TableName + "_GetRecent";
            List<DbParameter> dbParams = new List<DbParameter>();

            // Build input params to procedure.
            dbParams.Add(DbHelper.BuildInParam("@PageIndex", System.Data.DbType.Int32, pageNumber));
            dbParams.Add(DbHelper.BuildInParam("@PageSize", System.Data.DbType.Int32, pageSize));
            dbParams.Add(DbHelper.BuildOutParam("@TotalRows", System.Data.DbType.Int32));

            Tuple2<IList<T>, IDictionary<string, object>> result = DbHelper.Query<T>(
                procName, System.Data.CommandType.StoredProcedure, dbParams.ToArray(), _rowMapper, new string[] { "@TotalRows" });

            // Set the total records.
            int totalRecords = (int)result.Second["@TotalRows"];
            PagedList<T> pagedList = new PagedList<T>(pageNumber, pageSize, totalRecords, result.First);
            return pagedList;
        }


        /// <summary>
        /// Find all records matching the query string.
        /// </summary>
        /// <param name="queryString"></param>
        /// <returns></returns>
        public virtual IList<T> Find(string queryString)
        {
            return FindByQuery(queryString, true);
        }


        /// <summary>
        /// Find by the sql using the single parameter value.
        /// </summary>
        /// <param name="queryString"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public virtual IList<T> Find(string queryString, object value)
        {
            string filter = string.Format(queryString, value);
            return FindByQuery(filter, true);
        }


        /// <summary>
        /// Find by sql text using the parameters supplied.
        /// </summary>
        /// <param name="queryString"></param>
        /// <param name="values"></param>
        /// <returns></returns>
        public virtual IList<T> Find(string queryString, object[] values)
        {
            string filter = string.Format(queryString, values);
            return FindByQuery(filter, true);
        }


        /// <summary>
        /// Find by filter.
        /// </summary>
        /// <param name="queryString">The query, this can be either just a filter
        /// after the where clause or the entire sql</param>
        /// <returns></returns>
        public virtual IList<T> FindByQuery(string queryString, bool isFullSql)
        {
            string sql = queryString;
            if (!isFullSql)
            {
                string tableName = this.TableName;
                queryString = string.IsNullOrEmpty(queryString) ? string.Empty : " where " + queryString;
                sql = "select * from " + tableName + " " + queryString;
            }
            IList<T> results = _db.QueryNoParams<T>(sql, CommandType.Text, RowMapper);
            return results;
        }
        #endregion


        /// <summary>
        /// Execute the executor providing it the datacontext and table.
        /// </summary>
        /// <param name="executor"></param>
        protected void Execute(Action<DataContext, Table<T>> executor)
        {
            var conn = DbHelper.GetConnection();
            var ctx = new DataContext(conn);
            using (ctx)
            {
                conn.Open();
                // Get the LogEventEntity table
                Table<T> table = ctx.GetTable<T>();
                executor(ctx, table);
                conn.Close();
            }
        }


        /// <summary>
        /// Execute the executor providing it the datacontext only.
        /// </summary>
        /// <param name="executor"></param>
        protected void Execute(Action<DataContext> executor)
        {
            var conn = DbHelper.GetConnection();
            var ctx = new DataContext(conn);
            using (ctx)
            {
                conn.Open();
                executor(ctx);
                conn.Close();
            }
        }


        /// <summary>
        /// Copies all the mapped column property values from the updatedEntity to the original
        /// </summary>
        /// <param name="updatedEntity"></param>
        /// <param name="original"></param>
        protected void CopyValues(T updatedEntity, T original)
        {
            var props = AttributeHelper.GetPropsOnlyWithAttributes<ColumnAttribute>(updatedEntity);
            foreach (var prop in props)
            {
                ReflectionUtils.CopyPropertyValue(updatedEntity, original, prop);
            }
        }
    }
}
