using System;

void Main()
{
    SayHello("Hello World!");
} 

static void SayHello(string greeting)
{
	Console.WriteLine(greeting);
}


