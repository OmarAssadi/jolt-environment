//////////////////////////////////////////////////////////////////////////
//Hello.js - script file from Alternative Compiler tutorial

import System;
import System.Windows.Forms;

//css_reference "System.dll";
//css_reference "System.Windows.Forms.dll";

public class Class1 {
	public static function Main() {
		Console.WriteLine("Hello World! (JScript)");
		MessageBox.Show("Hello World! (JScript)")
	}
}


