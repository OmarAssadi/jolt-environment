using System;
using System.Windows.Forms;

void Main()
{	
    Console.WriteLine( "Hello World!" ); 
    MessageBox.Show( "Hello World!"); 
}
