using System;

public class ExternalClass
{
	static public void SayHello()
	{
		Console.WriteLine("Hello World!");
	}
}

